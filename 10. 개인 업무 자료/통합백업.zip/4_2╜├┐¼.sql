BEGIN
    adminRead();        --관리자 목록 조회
END;
/
BEGIN   
    prcSubjectRead();   -- 전체 개설과정의 과목 정보
END;  
/  
BEGIN
    r_teacher;  --교사명단, 수업가능 과목 조회
END;
/
BEGIN
     r_t_teacherName('구하늘'); --교사가 맡은 과정 조회
END;
/
BEGIN
    r_s_subjectSeq(1); --과목번호로 교육생 정보 조회    1자바 
END;
/
BEGIN
    r_st_studentName('구하늘'); -- 교육생 이름을 조회하여 성적정보 확인
END;
/
BEGIN 
    r_process;--과정조회
END;
/
begin
    pstudent_certifications();-- 학생 전체 목록과 보유한 자격증
end;
/
BEGIN
    studentEnter('강나라');    --해당 학생자격증관련 기업 목록
END;
/














--교사명단조회
CREATE OR REPLACE PROCEDURE r_teacher 
IS
    CURSOR cur_teacher IS
        SELECT 
            t.teacherName AS 교사이름, 
            t.teacherPw AS 비밀번호, 
            t.teacherTel AS 전화번호, 
            s.subjectName AS 강의가능과목
        FROM teacher t
            INNER JOIN tSubject ts ON t.teacherSeq = ts.teacherSeq
            INNER JOIN subject s ON ts.subjectSeq = s.subjectSeq;

    v_teacherName  Teacher.teacherName%TYPE;
    v_teacherPw    Teacher.teacherPw%TYPE;
    v_teacherTel   Teacher.teacherTel%TYPE;
    v_subjectName  Subject.subjectName%TYPE;
BEGIN
    FOR rec IN cur_teacher LOOP
        v_teacherName := rec.교사이름;
        v_teacherPw := rec.비밀번호;
        v_teacherTel := rec.전화번호;
        v_subjectName := rec.강의가능과목;

        DBMS_OUTPUT.PUT_LINE(
            v_teacherName || ' | ' ||
            v_teacherPw || ' | ' ||
            v_teacherTel || ' | ' ||
            v_subjectName
        );
    END LOOP;
END r_teacher;
/




-- 개설과정의 과목 정보
CREATE OR REPLACE PROCEDURE prcSubjectRead AS  
    CURSOR subject_cursor IS  
        SELECT   
            p.processSeq,  
            p.prcSubjectSeq,      
            p.subjectSeq,   
            s.subjectName,   
            p.prcSubjectSDate,   
            p.prcSubjectEDate,   
            t.teacherName,  
            b.bookName   
        FROM   
            prcSubject p  
        INNER JOIN   
            subject s ON p.subjectSeq = s.subjectSeq  
        INNER JOIN   
            process pr ON p.processSeq = pr.processSeq  
        INNER JOIN   
            teacher t ON pr.teacherSeq = t.teacherSeq  
        INNER JOIN   
            sbjectBook sb ON s.subjectSeq = sb.subjectSeq  
        INNER JOIN   
            book b ON sb.bookSeq = b.bookSeq;  

    rec subject_cursor%ROWTYPE; -- 커서의 레코드 타입 정의  
BEGIN  
    OPEN subject_cursor; -- 커서 열기  
    LOOP  
        FETCH subject_cursor INTO rec; -- 데이터 가져오기  
        EXIT WHEN subject_cursor%NOTFOUND; -- 모든 데이터를 읽었는지 확인  
        DBMS_OUTPUT.PUT_LINE('개설과정번호: ' || rec.processSeq ||  
                             ', 개설과정과목번호: ' || rec.prcSubjectSeq ||  
                             ', 과목번호: ' || rec.subjectSeq ||  
                             ', 과목명: ' || rec.subjectName ||  
                             ', 과목시작날짜: ' || rec.prcSubjectSDate ||  
                             ', 과목종료날짜: ' || rec.prcSubjectEDate ||  
                             ', 교사명: ' || rec.teacherName ||  
                             ', 교재명: ' || rec.bookName);  
    END LOOP;  

    CLOSE subject_cursor; -- 커서 닫기  
END prcSubjectRead; 
/





/* 해당 학생자격증관련 기업 목록  */
CREATE OR REPLACE PROCEDURE studentEnter (
    pstudentName IN VARCHAR2
)
IS
    CURSOR vcursor IS
        SELECT 
            e.enterName, 
            e.enterBuseo, 
            e.enterLocation, 
            e.enterSalary
        FROM studentCrtf sc
        INNER JOIN student s ON sc.studentSeq = s.studentSeq
        INNER JOIN crtf c ON c.crtfSeq = sc.crtfSeq
        INNER JOIN enter e ON c.crtfSeq = e.crtfSeq
        WHERE s.studentName = pstudentName;  
BEGIN  
    FOR rec IN vcursor LOOP
        dbms_output.put_line('기업명: ' || rec.enterName);
        dbms_output.put_line('부서: ' || rec.enterBuseo);
        dbms_output.put_line('위치: ' || rec.enterLocation);
        dbms_output.put_line('연봉: ' || rec.enterSalary);
        dbms_output.put_line('--------------------------------');
    END LOOP;
END studentEnter;
/




--pl/sql
CREATE OR REPLACE PROCEDURE pstudent_certifications IS
    -- 변수 선언
    vStudentName student.studentName%TYPE;
    vCrtfName crtf.crtfName%TYPE;

    -- 커서 선언
    CURSOR student_cursor IS
        SELECT 
            s.studentName AS studentName, 
            c.crtfName AS crtfName
        FROM studentCrtf sc
        INNER JOIN crtf c ON sc.crtfSeq = c.crtfSeq
        INNER JOIN student s ON s.studentSeq = sc.studentSeq;
BEGIN
    dbms_output.put_line('====================================================================');
    dbms_output.put_line('              학생 전체 목록과 보유한 자격증');
    dbms_output.put_line('====================================================================');
    

    OPEN student_cursor;

    -- 커서에서 데이터 하나씩 가져오기
    LOOP
        FETCH student_cursor INTO vStudentName, vCrtfName;

        -- 커서 끝에 도달하면 종료
        EXIT WHEN student_cursor%NOTFOUND;

        -- 학생 이름과 자격증 출력
        DBMS_OUTPUT.PUT_LINE('학생 이름: ' || vStudentName || ', 보유한 자격증: ' || vCrtfName);
    END LOOP;

    -- 커서 닫기
    CLOSE student_cursor;
EXCEPTION
    WHEN OTHERS THEN
        -- 오류 발생 시 예외 처리
        DBMS_OUTPUT.PUT_LINE('오류 발생: ' || SQLERRM);
END pstudent_certifications;
/






    



--과목을 조회하여 교육생 정보 출력
CREATE OR REPLACE PROCEDURE r_s_subjectSeq(
    p_s_subjectSeq subject.subjectSeq%TYPE
) IS
    v_studentName student.studentName%TYPE;
    v_studentTel student.studentTel%TYPE;
    v_educationStatus VARCHAR2(20);
    v_attendanceScore score.attendanceScore%TYPE;
    v_writingScore score.writingScore%TYPE;
    v_realScore score.realScore%TYPE;
    
    CURSOR subject_cursor IS
        SELECT 
            st.studentName,
            st.studentTel,
            CASE 
                WHEN ss.status = '수료' OR ss.status IS NULL THEN '수료'
                WHEN ss.stStatusDate >= p.processSDate AND ss.stStatusDate <= p.processEDate THEN '중도탈락'
                WHEN SYSDATE <= p.processSDate THEN '수강예정'
                WHEN SYSDATE >= p.processSDate AND SYSDATE <= p.processEDate THEN '수강중'
                ELSE '수료'
            END AS educationStatus,
            sc.attendanceScore,
            sc.writingScore,
            sc.realScore
        FROM student st
            INNER JOIN studentCls scs ON st.studentSeq = scs.studentSeq
            INNER JOIN process p ON scs.processSeq = p.processSeq
            INNER JOIN prcSubject ps ON p.processSeq = ps.processSeq
            INNER JOIN subject s ON ps.subjectSeq = s.subjectSeq
            LEFT JOIN stStatus ss ON st.studentSeq = ss.studentSeq
            INNER JOIN score sc ON st.studentSeq = sc.studentSeq AND s.subjectSeq = sc.subjectSeq
        WHERE 
            s.subjectSeq = p_s_subjectSeq
            AND p.processSDate <= ps.prcSubjectSDate
            AND p.processEDate >= ps.prcSubjectEDate;
BEGIN
    OPEN subject_cursor;
    LOOP
        FETCH subject_cursor INTO 
            v_studentName, v_studentTel, v_educationStatus, v_attendanceScore, v_writingScore, v_realScore;
        
        EXIT WHEN subject_cursor%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('과목번호로 조회된 교육생 정보');
        DBMS_OUTPUT.PUT_LINE('이름: ' || v_studentName || ', 전화번호: ' || v_studentTel || ', 교육생 상태: ' || v_educationStatus);
        DBMS_OUTPUT.PUT_LINE('출석점수: ' || v_attendanceScore || ', 필기점수: ' || v_writingScore || ', 실기점수: ' || v_realScore);
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    END LOOP;
    
    CLOSE subject_cursor;
END;
/



--/*조회*/AdminRead
CREATE OR REPLACE PROCEDURE adminRead IS  
    CURSOR admin_cursor IS  
        SELECT AdminSeq ,   
               AdminName,   
               AdminTel ,   
               AdminPw   
        FROM Admin;  

    v_AdminSeq Admin.AdminSeq%TYPE;  
    v_AdminName Admin.AdminName%TYPE;  
    v_AdminTel Admin.AdminTel%TYPE;  
    v_AdminPw Admin.AdminPw%TYPE;  

BEGIN  
    OPEN admin_cursor;  -- 커서를 여는 부분  

    LOOP  
        FETCH admin_cursor INTO v_AdminSeq, v_AdminName, v_AdminTel, v_AdminPw;  -- 커서로부터 값을 읽어옴  
        EXIT WHEN admin_cursor%NOTFOUND;  -- 더 이상 읽을 것이 없으면 루프 종료  

        -- 결과 출력  
        DBMS_OUTPUT.PUT_LINE('관리자 번호: ' || v_AdminSeq ||   
                             ', 관리자 이름: ' || v_AdminName ||   
                             ', 전화번호: ' || v_AdminTel ||   
                             ', 비밀번호: ' || v_AdminPw);  
    END LOOP;  

    CLOSE admin_cursor;  -- 커서를 닫는 부분  

EXCEPTION  
    WHEN OTHERS THEN  
        DBMS_OUTPUT.PUT_LINE('오류 발생: ' || SQLERRM);   
END;  
/



CREATE OR REPLACE PROCEDURE r_t_teacherName(
    p_teacherName Teacher.teacherName%TYPE
)
IS
    CURSOR cur_TeacherLecture IS
        SELECT 
            t.teacherName AS 교사이름,
            s.subjectName AS 과목명,
            ps.prcSubjectSDate AS 과목시작날짜,
            ps.prcSubjectEDate AS 과목종료날짜,
            c.courseName AS 과정명,
            p.processSDate AS 과정시작날짜,
            p.processEDate AS 과정종료날짜,
            b.bookName AS 교재명,
            cr.clsRoomName AS 강의실명,
            CASE
                WHEN ps.prcSubjectSDate > SYSDATE THEN '강의예정'
                WHEN ps.prcSubjectSDate <= SYSDATE AND ps.prcSubjectEDate >= SYSDATE THEN '강의중'
                ELSE '강의종료'
            END AS 강의진행여부
        FROM teacher t
            INNER JOIN process p ON t.teacherSeq = p.teacherSeq
            INNER JOIN prcSubject ps ON p.processSeq = ps.processSeq
            INNER JOIN subject s ON ps.subjectSeq = s.subjectSeq
            INNER JOIN Course c ON p.courseSeq = c.courseSeq
            INNER JOIN clsRoom cr ON p.clsRoomSeq = cr.clsRoomSeq
            INNER JOIN sbjectBook sb ON s.subjectSeq = sb.subjectSeq
            INNER JOIN book b ON sb.bookSeq = b.bookSeq
        WHERE t.teacherName = p_teacherName;

    v_teacherName    Teacher.teacherName%TYPE;
    v_subjectName    Subject.subjectName%TYPE;
    v_prcSubjectSDate prcSubject.prcSubjectSDate%TYPE;
    v_prcSubjectEDate prcSubject.prcSubjectEDate%TYPE;
    v_courseName     Course.courseName%TYPE;
    v_processSDate   Process.processSDate%TYPE;
    v_processEDate   Process.processEDate%TYPE;
    v_bookName       Book.bookName%TYPE;
    v_clsRoomName    clsRoom.clsRoomName%TYPE;
    v_lectureStatus  VARCHAR2(20);
BEGIN
    FOR rec IN cur_TeacherLecture LOOP
        v_teacherName := rec.교사이름;
        v_subjectName := rec.과목명;
        v_prcSubjectSDate := rec.과목시작날짜;
        v_prcSubjectEDate := rec.과목종료날짜;
        v_courseName := rec.과정명;
        v_processSDate := rec.과정시작날짜;
        v_processEDate := rec.과정종료날짜;
        v_bookName := rec.교재명;
        v_clsRoomName := rec.강의실명;
        v_lectureStatus := rec.강의진행여부;

        DBMS_OUTPUT.PUT_LINE(
            v_teacherName || ' | ' ||
            v_subjectName || ' | ' ||
            TO_CHAR(v_prcSubjectSDate, 'YYYY-MM-DD') || ' | ' ||
            TO_CHAR(v_prcSubjectEDate, 'YYYY-MM-DD') || ' | ' ||
            v_courseName || ' | ' ||
            TO_CHAR(v_processSDate, 'YYYY-MM-DD') || ' | ' ||
            TO_CHAR(v_processEDate, 'YYYY-MM-DD') || ' | ' ||
            v_bookName || ' | ' ||
            v_clsRoomName || ' | ' ||
            v_lectureStatus
        );
    END LOOP;
END r_t_teacherName;
/


-- 교육생 이름을 조회하여 성적정보 확인
CREATE OR REPLACE PROCEDURE r_st_studentName(
    p_studentName student.studentName%TYPE
) IS
    v_studentName student.studentName%TYPE;
    v_studentPw student.studentPw%TYPE;
    v_courseName Course.courseName%TYPE;
    v_processSDate process.processSDate%TYPE;
    v_processEDate process.processEDate%TYPE;
    v_clsRoomName clsRoom.clsRoomName%TYPE;
    v_subjectName subject.subjectName%TYPE;
    v_prcSubjectSDate prcSubject.prcSubjectSDate%TYPE;
    v_prcSubjectEDate prcSubject.prcSubjectEDate%TYPE;
    v_teacherName teacher.teacherName%TYPE;
    v_attendanceScore score.attendanceScore%TYPE;
    v_writingScore score.writingScore%TYPE;
    v_realScore score.realScore%TYPE;
    
    CURSOR student_cursor IS
        SELECT 
            st.studentName,
            st.studentPw,
            c.courseName,
            p.processSDate,
            p.processEDate,
            cr.clsRoomName,
            s.subjectName,
            ps.prcSubjectSDate,
            ps.prcSubjectEDate,
            t.teacherName,
            sc.attendanceScore,
            sc.writingScore,
            sc.realScore
        FROM student st
            INNER JOIN studentCls scs ON st.studentSeq = scs.studentSeq
            INNER JOIN process p ON scs.processSeq = p.processSeq
            INNER JOIN Course c ON p.courseSeq = c.courseSeq
            INNER JOIN clsRoom cr ON p.clsRoomSeq = cr.clsRoomSeq
            INNER JOIN prcSubject ps ON p.processSeq = ps.processSeq
            INNER JOIN subject s ON ps.subjectSeq = s.subjectSeq
            INNER JOIN sbjectBook sb ON s.subjectSeq = sb.subjectSeq
            INNER JOIN book b ON sb.bookSeq = b.bookSeq
            INNER JOIN teacher t ON p.teacherSeq = t.teacherSeq
            INNER JOIN score sc ON st.studentSeq = sc.studentSeq AND s.subjectSeq = sc.subjectSeq
        WHERE 
            st.studentName = p_studentName;
BEGIN
    OPEN student_cursor;
    LOOP
        FETCH student_cursor INTO 
            v_studentName, v_studentPw, v_courseName, v_processSDate, v_processEDate, v_clsRoomName, v_subjectName, v_prcSubjectSDate, v_prcSubjectEDate, v_teacherName, v_attendanceScore, v_writingScore, v_realScore;
        
        EXIT WHEN student_cursor%NOTFOUND;
        dbms_output.put_line('교육생 이름으로 조회된 성적정보');
        DBMS_OUTPUT.PUT_LINE('학생이름: ' || v_studentName || ', 주민번호뒷자리: ' || v_studentPw);
        DBMS_OUTPUT.PUT_LINE('과정명: ' || v_courseName || ', 과정시작날짜: ' || v_processSDate || ', 과정종료날짜: ' || v_processEDate);
        DBMS_OUTPUT.PUT_LINE('강의실명: ' || v_clsRoomName || ', 과목명: ' || v_subjectName);
        DBMS_OUTPUT.PUT_LINE('과목시작날짜: ' || v_prcSubjectSDate || ', 과목종료날짜: ' || v_prcSubjectEDate);
        DBMS_OUTPUT.PUT_LINE('교사명: ' || v_teacherName);
        DBMS_OUTPUT.PUT_LINE('출석점수: ' || v_attendanceScore || ', 필기점수: ' || v_writingScore || ', 실기점수: ' || v_realScore);
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    END LOOP;
    
    CLOSE student_cursor;
END;
/



CREATE OR REPLACE PROCEDURE r_process
IS
    CURSOR cur_process IS
        SELECT 
            c.courseName AS 과정명,
            p.processSDate AS 과정시작날짜,
            p.processEDate AS 과정종료날짜,
            cr.clsRoomName AS 강의실명,
            s.subjectName AS 과목명,
            (SELECT COUNT(*) 
             FROM studentCls sc 
             WHERE sc.processSeq = p.processSeq) AS 교육생등록인원
        FROM process p
            INNER JOIN Course c ON p.courseSeq = c.courseSeq
            INNER JOIN clsRoom cr ON p.clsRoomSeq = cr.clsRoomSeq
            INNER JOIN prcSubject ps ON p.processSeq = ps.processSeq
            INNER JOIN subject s ON ps.subjectSeq = s.subjectSeq;

    v_courseName       Course.courseName%TYPE;
    v_processSDate     Process.processSDate%TYPE;
    v_processEDate     Process.processEDate%TYPE;
    v_clsRoomName      clsRoom.clsRoomName%TYPE;
    v_subjectName      subject.subjectName%TYPE;
    v_studentCount     NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('과정명 | 시작일 | 종료일 | 강의실 | 과목명 | 등록인원');
    DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------');

    FOR rec IN cur_process LOOP
        v_courseName := rec.과정명;
        v_processSDate := rec.과정시작날짜;
        v_processEDate := rec.과정종료날짜;
        v_clsRoomName := rec.강의실명;
        v_subjectName := rec.과목명;
        v_studentCount := rec.교육생등록인원;

        DBMS_OUTPUT.PUT_LINE(
            v_courseName || ' | ' || 
            TO_CHAR(v_processSDate, 'YYYY-MM-DD') || ' | ' || 
            TO_CHAR(v_processEDate, 'YYYY-MM-DD') || ' | ' || 
            v_clsRoomName || ' | ' || 
            v_subjectName || ' | ' || 
            v_studentCount
        );
    END LOOP;
END r_process;
/
