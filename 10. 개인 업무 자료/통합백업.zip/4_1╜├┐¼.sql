
--4.교재명 관리
--교재명을 등록, 수정, 삭제, 조회 할 수 있다.
--1과목에는 교재 1권이 존재한다.

select * 
from book;
/*추가*/
insert into book(bookSeq,bookName,bookPublisher,bookAuthor,bookYear) 
values (book_Seq.NEXTVAL, q'[최신Java 프로그래밍]', q'[21세기사]', q'[한정란]', to_date('2024','YYYY'));
/*조회*/
select bookSeq as 교재번호, bookName as 교재명, bookPublisher as 출판사 , bookAuthor as 저자 ,bookYear as 발행연도 
from book;
/*수정*/
update book 
   set bookName = q'[최신Java 프로그래밍]'
   , bookPublisher = q'[21세기사]'
   , bookAuthor = q'[한정란]'
   , bookYear = to_date('2024','YYYY')
where bookSeq = 1;


--------------------------------------------------------------------------------
commit;
rollback;
/*삭제*/
UPDATE book  
set bookName = '없음'
   , bookPublisher = null
   , bookAuthor = null
   , bookYear = null 
WHERE bookSeq = 1;  
--------------------------------------------------------------------------------





/*  C-04 교사 - 성적 관리  */
    
/*조회*/
--교사 이름을 입력하여 강의를 마친 과목 조회
--------------------------------------------------------------------------------
SELECT 
    s.subjectSeq AS 과목번호,
    c.courseName AS 과정명,
    p.processSDate AS 과정시작날짜,
    p.processEDate AS 과정종료날짜,
    cr.clsRoomName AS 강의실명,
    s.subjectName AS 과목명,
    ps.prcSubjectSDate AS 과목시작날짜,
    ps.prcSubjectEDate AS 과목종료날짜,
    b.bookName AS 교재명,
    st.studentName AS 이름,
    sa.attendAllot AS 출석배점,
    sa.writingAllot AS 필기배점,
    sa.realAllot AS 실기배점,
    CASE 
        WHEN sc.studentSeq IS NOT NULL THEN '등록'
        ELSE '미등록'
    END AS 성적등록여부
FROM teacher t
    inner join process p ON t.teacherSeq = p.teacherSeq
    inner join Course c ON p.courseSeq = c.courseSeq
    inner join clsRoom cr ON p.clsRoomSeq = cr.clsRoomSeq
    inner join prcSubject ps ON p.processSeq = ps.processSeq
    inner join subject s ON ps.subjectSeq = s.subjectSeq
    inner join sbjectBook sb ON s.subjectSeq = sb.subjectSeq
    inner join book b ON sb.bookSeq = b.bookSeq
    inner join studentCls scs ON p.processSeq = scs.processSeq
    inner join student st ON scs.studentSeq = st.studentSeq
    left join score sc ON st.studentSeq = sc.studentSeq AND s.subjectSeq = sc.subjectSeq
    inner join scoreAllot sa ON ps.prcSubjectSeq = sa.prcSubjectSeq
WHERE 
    t.teacherName = '구하늘'   --1강의실 구하늘, 3강의실 최레이
    AND ps.prcSubjectEDate <= SYSDATE
    AND p.processSDate <= ps.prcSubjectSDate
    AND p.processEDate >= ps.prcSubjectEDate;
    --------------------------------------------------------------------------------
 





--과목을 조회하여 교육생 정보 출력
--------------------------------------------------------------------------------
SELECT 
    st.studentName AS 이름,
    st.studentTel AS 전화번호,
    CASE 
        WHEN ss.status = '수료' OR ss.status IS NULL THEN '수료'
        WHEN ss.stStatusDate >= p.processSDate AND ss.stStatusDate <= p.processEDate THEN '중도탈락'
        WHEN SYSDATE <= p.processSDate THEN '수강예정'
        WHEN SYSDATE >= p.processSDate AND SYSDATE <= p.processEDate THEN '수강중'
        ELSE '수료'
    END AS 교육생상태,
    sc.attendanceScore AS 출석점수,
    sc.writingScore AS 필기점수,
    sc.realScore AS 실기점수
FROM student st
    inner join studentCls scs ON st.studentSeq = scs.studentSeq
    inner join process p ON scs.processSeq = p.processSeq
    inner join prcSubject ps ON p.processSeq = ps.processSeq
    inner join subject s ON ps.subjectSeq = s.subjectSeq
    left join stStatus ss ON st.studentSeq = ss.studentSeq
    inner join score sc ON st.studentSeq = sc.studentSeq AND s.subjectSeq = sc.subjectSeq
WHERE 
    s.subjectSeq = 1    --자바 1, 오라클 27
    AND p.processSDate <= ps.prcSubjectSDate
    AND p.processEDate >= ps.prcSubjectEDate;
--------------------------------------------------------------------------------








/*
2. 교육생 정보 출력
- 이름, 주민번호 뒷자리, 전화번호, 등록일 확인 가능하다.
*/
/*조회*/
--2
select studentName as 이름, studentPw as 주민번호, studentTel as 전화번호, studentDate as 등록일 
from Student;

--3    
select
st.studentname as 이름,
c.coursename as 과정명,
pr.processSDate as 과정시작날짜,
pr.processEDate as 과정종료날짜,
clR.clsroomname as 강의실,
CASE   
        WHEN stS.Status IS NULL THEN '수료중'  
        ELSE stS.Status    
END AS 수료여부,
stS.stStatusDate as 날짜
from Student st
    INNER JOIN   
    studentCls stcl ON st.studentSeq = stcl.studentSeq
    INNER JOIN   
    process pr ON stcl.processSeq = pr.processSeq
    INNER JOIN   
    Course c ON pr.courseSeq = c.courseSeq
    INNER JOIN   
    clsRoom clR ON pr.clsRoomSeq = clR.clsRoomSeq
    LEFT JOIN  
    stStatus stS ON st.studentSeq = stS.studentSeq
where st.studentSeq = 1;










/*  B-07 관리자 - 시험관리, 성적조회  */

/*조회*/
-- 개설과정번호를 조회하여 시험문제 확인
--------------------------------------------------------------------------------
SELECT 
    c.courseName AS 과정명,
    s.subjectName AS 과목명,
    t.testType AS 시험종류,
    t.testContext AS 시험문제,
    t.testDate AS 날짜
FROM process p
    inner join Course c ON p.courseSeq = c.courseSeq
    inner join prcSubject ps ON p.processSeq = ps.processSeq
    inner join subject s ON ps.subjectSeq = s.subjectSeq
    inner join test t ON s.subjectSeq = t.subjectSeq
WHERE 
    p.processSeq = 2
    AND t.teacherSeq = p.teacherSeq     --티쳐테이블의 교사번호, 과정테이블의 교사번호 매칭
    AND t.testDate < p.processEDate;    --티쳐테이블의 시험날짜, 과정테이블의 시험날짜 필터
    --------------------------------------------------------------------------------
    
    
    
    
    
    
    
    
    
--추가기능,


/*  공휴일  */

/*추가*/
select * from holiday;
    
    
    
    
    
    
    
    
    --기업 조회
    
    
    /*조회*/
select * from enter;



--자격증 조회
/*조회*/
select * from crtf;
    
    
    
    
    
    
    
/*  교육생의 이름과 자격증  */

/*조회*/
select 
    s.studentName as "학생 이름", 
    c.crtfName as "보유한 자격증"
from studentCrtf sc 
inner join crtf c on sc.crtfSeq = c.crtfSeq
inner join student s on s.studentSeq = sc.studentSeq;









    
/*  해당 학생자격증관련 기업 목록  */

/*조회*/
select 
    e.enterName as "기업명", 
    e.enterBuseo as "업무 내용", 
    e.enterLocation as "회사 위치", 
    e.enterSalary as "평균 연봉"
from studentCrtf sc
inner join student s on sc.studentSeq = s.studentSeq
inner join crtf c on c.crtfSeq = sc.crtfSeq
inner join enter e on c.crtfSeq = e.crtfSeq
where s.studentName = '강나라';







/*  과정평가  */


/*조회*/
select * from cGrade;







/*  학생 전체 시험 평균점수   */

/*조회*/
SELECT 
    ST.STUDENTNAME as "학생 이름", 
    ROUND(AVG(SC.TOTALSCORE), 1) AS "평균 점수"
FROM STUDENT ST
    INNER JOIN SCORE SC
        ON ST.STUDENTSEQ = SC.STUDENTSEQ
GROUP BY ST.STUDENTNAME; 






